{
    'name': 'Hospital Management',
    'author': 'Dev',
    'application': True,
    'summary': 'For Testing purposes!',
    'depends': [
        'mail'
    ],
    'data':[
        'security/ir.model.access.csv',
        'views/menu.xml',
        'views/patient.xml',
    ]
}