from odoo import api, fields, models


class HospitalPatient(models.Model):
    _name = "hospital.patient"
    _inherit = ['mail.thread']
    _description = "Patient's Records"

    sequence_no = fields.Char('Sequence Number', readonly=True)
    name = fields.Char(string="Patient Name", required=True, tracking=True)
    age = fields.Integer(string="Age")
    is_child = fields.Boolean(string="Is Child?")
    notes = fields.Text(string="Notes")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('others', 'Others')], string="Gender")

    def create(self,vals):
        
